<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package Catch Themes
 * @subpackage Catch_Box
 * @since Catch Box 1.0
 */
?>

	</div><!-- #main -->

	<?php 
    /** 
     * catchbox_after_main hook
     */
    do_action( 'catchbox_after_main' ); 
    ?>      

	<footer id="colophon" role="contentinfo">
		<?php
        /** 
         * catchbox_before_footer_menu hook
         */
        do_action( 'catchbox_before_footer_sidebar' );
	
		/* A sidebar in the footer? Yep. You can can customize
		 * your footer with three columns of widgets.
		 */
		get_sidebar( 'footer' );
				
		/** 
		 * catchbox_before_footer_menu hook
		 */
		do_action( 'catchbox_after_footer_sidebar' );
		
		/** 
		 * catchbox_before_footer_menu hook
		 */
		do_action( 'catchbox_before_footer_menu' ); 		
		
		if ( has_nav_menu( 'footer', 'catchbox' ) ) {
			// Check is footer menu is enable or not
			$options = catchbox_get_theme_options();
			if ( !empty ($options ['enable_menus'] ) ) :
				$menuclass = "mobile-enable";
			else :
				$menuclass = "mobile-disable";
			endif;
			?>
			<nav id="access-footer" class="<?php echo $menuclass; ?>" role="navigation">
				<h3 class="assistive-text"><?php _e( 'Footer menu', 'catchbox' ); ?></h3>
				<?php wp_nav_menu( array( 'theme_location'  => 'footer', 'container_class' => 'menu-footer-container', 'depth' => 1 ) );  ?>
			</nav>
       	<?php 
		} 
		
		/** 
		 * catchbox_before_footer_menu hook
		 */
		do_action( 'catchbox_after_footer_menu' ); ?>
        
        <div id="site-generator" class="clearfix">
        
          <div class="final_bottom_box">
<div class="bottom_scroll"><marquee direction="left" loop="50" width="100%" scrollamount="2">::Applications are invited from eligible Exporters/Persons/Organizations for consideration for the Coir Industry Awards for outstanding performance in the coir sector for the year 2012-13. ::  Shri Surendra Nath Tripathi has been appointed Joint Secretary to Ministry of Micro, Small and Medium Enterprises , Government of India, he is a 1985 batch IAS officer of Orissa cadre.  :: Coir Industry Awards for the year 2011-12 were presented by His Excellency the President of India, Shri Pranab Mukherjee and Shri. K.H.Muniyappa, Hon ble Minister of State with Independent Charge of Micro, Small Medium Enterprises in the presence of Prof G. Balachandran,Chairman, Coir Board at the National Award&nbsp; to Micro, Small and Medium Enterprises, function held at the Vigyan Bhavan, New Delhi on 3rd April 2013:: Coir Board TOLL FREE NUMBER 18004259091 will be active from 9.00 AM to 5.30PM on all working days ::</marquee></div>

<div class="bottom_btn_btn">

<a href="http://coirboard.coirexpo.com/rti/">RTI</a>    &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/grievances/">Grievances</a>     &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/notifications/">Notification</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Anouncement</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/statistics/">Statistics</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="#"></a><a href="http://coirboard.coirexpo.com/reports/">Reports </a>   &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Forms</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/coir-industry-act/">Acts&amp;Rules </a>   &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/articles/">Articles </a>  &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/career/">Career </a>  &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/publications/">Publications</a>   &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/circulars/">Circulars</a>   &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/buyers/">Buying   &nbsp;&nbsp;&nbsp;&nbsp; </a><a href="#">Agents    &nbsp;&nbsp;&nbsp;&nbsp;</a><a href="#"></a><a href="http://coirboard.coirexpo.com/machinery/">Machinery</a> &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Manufactures</a>   &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/circulars/">Trade Circulars </a>   &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/trade-fairs/">Trade Events </a>
                                                                                               &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/machinery/">Machinery</a> <a href="http://coirboard.coirexpo.com/machinery-suppliers/">Suppliers</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/citizen-charter/">Citizen Charter</a>   &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://coirboard.coirexpo.com/export-directory/">Exporters Directory </a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/coir-news/">Coir News</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="#">FAQ</a>    &nbsp;&nbsp;&nbsp;&nbsp;<a href="http://coirboard.coirexpo.com/invitations/">Invitations</a>

</div>
<div class="footer">© 2014 Coirboard. All Rights Reserved Designed &amp; Developed by NOVASOFT</div>
</div>
            
        </div> <!-- #site-generator -->
        
	</footer><!-- #colophon -->
    
</div><!-- #page -->

<?php 
/** 
 * catchbox_after hook
 */
do_action( 'catchbox_after' );
?>

<?php wp_footer(); ?>

</body>
</html>