 </div>
	<script>
		jQuery("#show-nav").click(function(){
			jQuery(".main-nav").toggle("slow");
		
		});

	</script>
  </body>


</html> 
